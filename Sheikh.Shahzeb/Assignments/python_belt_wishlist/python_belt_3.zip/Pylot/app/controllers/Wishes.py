from system.core.controller import *

class Wishes(Controller):
	def __init__(self, action):
		super(Wishes, self).__init__(action)
		self.load_model('Wish')

	def add_wish(self, id):
		result = self.models['Wish'].add_wish(id,session['user']['id'])
		return redirect('/success')

	def remove_wish(self, id):
		print 'this is the id =',id
		destroy = self.models['Wish'].remove_wish(id)
		return redirect('/success')