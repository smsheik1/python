from system.core.controller import *

class Items(Controller):
	def __init__(self, action):
		super(Items, self).__init__(action)
		self.load_model('Item')
	
	def add(self):
		result = self.models['Item'].add_item(request.form.copy(), session['user']['id'])
		return redirect('/success')
	def delete(self, id):
		destroy = self.models['Item'].delete_item(id)
		return redirect('/success')