from system.core.controller import *

class Users(Controller):
	def __init__(self, action):
		super(Users, self).__init__(action)
		self.load_model('User')
		self.load_model('Item')
		self.load_model('Wish')
	def index(self):
		if 'user' in session:
			return redirect('/success')
		return self.load_view('index.html')

	def register(self):
		user = self.models['User'].register_user(request.form.copy())
		if user['status'] == False:
			for message in user['errors']:
				flash(message)
			return redirect('/')
		session['user']= user['hold_query'][0]
		return redirect('/success')



	def success(self):
		items = self.models['User'].get_all_items(session['user']['id'])
		wish_list = self.models['User'].show_wish_list(session['user']['id'])
		return self.load_view('success.html', items= items, wish_list= wish_list)

	def login(self):
		user=self.models['User'].login_user(request.form.copy())
		print "line 31"
		print user
		if user['status'] ==False:
			for message in user['errors']:
				flash(message)
			return redirect('/')
		if user['status'] ==True:
			session['user'] = user['hold_query'][0]
			print("printing session {}".format(session['user']))
			return redirect('/success')


	def logout(self):
		session.clear()
		return self.load_view('index.html')







		

