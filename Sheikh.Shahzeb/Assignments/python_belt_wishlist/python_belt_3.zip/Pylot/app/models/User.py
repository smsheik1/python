from system.core.model import Model
import re
class User(Model):
    def __init__(self):
        super(User, self).__init__()

    def get_all_users(self):
        return self.db.query_db("SELECT * FROM users")

    def register_user(self, info):
      EMAIL_REGEX = re.compile(r'^[a-za-z0-9\.\+_-]+@[a-za-z0-9\._-]+\.[a-za-z]*$')
      errors = []
      if not info['first_name']:
        errors.append('Name cannot be blank')
      elif len(info['first_name']) < 2:
        errors.append('first name must be atleast 2 characters long')

      if not info['last_name']:
        errors.append('last name cannot be blank')
      elif len(info['last_name']) <2:
        errors.append('last name must be atleast 2 characters long')

      if not info['username']:
        errors.append('username cannot be blank')
      elif len(info['username']) <3:
        errors.append('username must be atleast 3 characters')

      if not info['email']:
        errors.append('email cannot be blank')
      elif not EMAIL_REGEX.match(info['email']):
        errors.append('Email format must be valid!')

      if not info['password']:
        errors.append('password cannot be blank')
      elif len(info['password']) <8:
        errors.append('Password must be at least 8 characters long')

      if errors:
        return {"status":False, "errors" :errors}
      else:
        print "this is working" 
        hashed_pw = self.bcrypt.generate_password_hash(info['password'])
        query = "INSERT INTO users (first_name, last_name, email, username, password, created_at) VALUES (:first_name, :last_name,:email,:username, :pw_hash, NOW())"
        data = { 'first_name': info['first_name'], 'last_name': info['last_name'], 'username':info['username'], 'email': info['email'], 'pw_hash':hashed_pw }
        user_id = self.db.query_db(query, data)

        query = "SELECT * FROM users WHERE email= :email"
        data = {'email': info['email']}
        hold_query = self.db.query_db(query,data)
        print hold_query
        return {'status':True, 'hold_query': hold_query}
        # get_user_query = "SELECT * FROM users ORDER by id LIMIT 1"
        # users = self.db.query_db(get_user_query)
        # return { "status": True, "user": users[0] }
    def login_user(self, info):
      password = info['password']
      user_query = "SELECT * FROM users WHERE email = :email LIMIT 1"
      user_data = {'email': info['email']}
      errors= []
      user = self.db.query_db(user_query, user_data)
      if user:
        if self.bcrypt.check_password_hash(user[0]['password'], password):
          return {'status':True, 'hold_query':user}
        errors.append('you have inserted an invalid response')
        if errors:
          print "in if errors in model"
          return {'status':False, 'errors':errors}
      else:
        errors.append('nah fam')
        return {'status':False, 'errors':errors}


    def get_all_items(self, users_id):
      query = "SELECT items.item,users.username,items.id FROM items JOIN users ON users.id = items.users_id LEFT JOIN wish_list ON items.id = wish_list.items_id AND wish_list.users_id = :users_id WHERE wish_list.users_id IS NULL"
      data = {'users_id': users_id}
      return self.db.query_db(query, data)


    def show_wish_list(self, users_id):
      query = "SELECT items.item, u.username, wish_list.id FROM items JOIN wish_list ON items.id = wish_list.items_id JOIN users u ON u.id = wish_list.users_id WHERE u.id = :users_id"
      data = {'users_id': users_id}
      return self.db.query_db(query,data)



