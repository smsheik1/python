from system.core.model import Model

class Wish(Model):
	def __init__(self):
		super(Wish, self).__init__()

	def add_wish(self,items_id,users_id):
		query= "INSERT INTO wish_list(users_id,items_id) VALUES (:users_id, :items_id)"
		data = {'users_id': users_id, 'items_id':items_id}
		return self.db.query_db(query,data)

	def remove_wish(self,wish_list_id):
		query= "DELETE FROM wish_list where wish_list.id=:wish_list_id"
		data = {'wish_list_id':wish_list_id}
		return self.db.query_db(query,data)