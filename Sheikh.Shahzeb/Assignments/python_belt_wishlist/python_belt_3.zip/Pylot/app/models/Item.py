from system.core.model import Model

class Item(Model):
	def __init__(self):
		super(Item, self).__init__()	
	
	def add_item(self, info, id):
		query = "INSERT INTO items (item, users_id) VALUES (:item, :id)"
		data = {'item': info['item'], 'id': id }
		return self.db.query_db(query, data)

	def delete_item(self, item_id):
		query = "DELETE FROM items WHERE id = :item_id"
		data = { 'item_id': item_id }
		return self.db.query_db(query, data)